<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;

    // A post belongs to a user
    // to get the owner of the post
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // to get the categories under the post
    public function categoryPost()
    {
        return $this->hasMany(CategoryPost::class);
    }
}
