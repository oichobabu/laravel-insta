@extends('layouts.app')

@section('title', 'Show Post')

@section('content')
<div class="row border shadow">
  <!-- FIRST COLUMN -->
  <div class="col p-0 border-end">
    <img src="{{ $post->image }}" alt="post id {{ $post->id }}" class="w-100">
  </div>

  <!-- SECOND COLUMN -->
  <dic class="col-4 px-0 bg-white">
    <div class="card border-0">
      
      <!-- FIRST COLUMN -->
      <div class="row align-items-center">
        <div class="col-auto">
          <a href="#">
            @if ($post->user->avatar)
            <img src="#" alt="{{ $post->user->name}}" class="rounded-circle avatar-sm">
            @else
            <i class="fa-solid fa-circle-user text-secondary icon-sm"></i>
            @endif
          </a>
        </div>
        
        <!-- SECOND COLUMN -->
        <div class="col ps-0">
          <a href="#" class="text-decoration-none text-dark">{{ $post->user->name }}</a>
        </div>
        
        <!-- THIRD COLUMN -->
        <div class="col-auto">
          <div class="dropdown">
            <button class="btn btn-sm shadow-none" data-bs-toggle="dropdown">
              <i class="fa-solid fa-ellipsis"></i>
            </button>
            
            <!-- if you are the owner of the post, you can edit or delete the post -->
            @if (Auth::user()->id === $post->user->id)
            <div class="dropdown-menu">
              <a href="3" class="dropdown-item">
                <i class="fa-regular fa-pen-to-square"></i> Edit
              </a>
              
              <button class="dropdown-item text-danger" data-bs-toggle="modal" data-bs-target="#delete-post-{{ $post->id }}">
                <i class="fa-regular fa-trash-can"></i> Delete
              </button>
            </div>
            @include('users.posts.contents.modals.delete')
            @else
            <!-- if you are not the owner of the psot, show an unfollow button -->
            <!-- to be discussed soon -->
            <div class="dropdown-menu">
              <form action="#" method="post">
                @csrf
                @method('DELETE')
                
                <button type="submit" class="dropdown-item text-danger">Unfollow</button>
              </form>
            </div>
            @endif
          </div>
        </div>
      </div>
      <!-- first column -->
      <div class="card-header bg-white py-3"></div>
      <!-- second column -->
      <div class="card-body w-100"></div>
    </div>
  </div>
</div>
@endsection