<div class="card-header bg-white py-3">
  <div class="row align-items-center">

    <!-- FIRST COLUMN -->
    <div class="col-auto">
      <a href="#">
        <?php if($post->user->avatar): ?>
          <img src="#" alt="<?php echo e($post->user->name); ?>" class="rounded-circle avatar-sm">
        <?php else: ?>
          <i class="fa-solid fa-circle-user test-secondary icon-sm"></i>
        <?php endif; ?>
      </a>
    </div>

    <!-- SECOND COLUMN -->
    <div class="col ps-0">
      <a href="#" class="text-decoration-none text-dark"><?php echo e($post->user->name); ?></a>
    </div>

    <!-- THIRD COLUMN -->
    <div class="col-auto">
      <div class="dropdown">
        <button class="btn btn-sm shadow-none" data-bs-toggle="dropdown">
          <i class="fa-solid fa-ellipsis"></i>
        </button>

        <!-- if you are the owner of the post, you can edit or delete the post -->
        <?php if(Auth::user()->id === $post->user->id): ?>
          <div class="dropdown-menu">
            <a href="3" class="dropdown-item">
              <i class="fa-regular fa-pen-to-square"></i> Edit
            </a>

            <button class="dropdown-item text-danger" data-bs-toggle="modal" data-bs-target="#delete-post-<?php echo e($post->id); ?>">
              <i class="fa-regular fa-trash-can"></i> Delete
            </button>
          </div>
          <?php echo $__env->make('users.posts.contents.models.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
          <!-- if you are not the owner of the psot, show an unfollow button -->
          <!-- to be discussed soon -->
          <div class="dropdown-menu">
            <form action="#" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>

              <button type="submit" class="dropdown-item text-danger">Unfollow</button>
            </form>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div><?php /**PATH /Applications/MAMP/htdocs/laravel-insta/laravel-insta/resources/views/users/posts/contents/title.blade.php ENDPATH**/ ?>